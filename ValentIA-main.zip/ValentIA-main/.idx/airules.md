# AutoFlota-AI — Reglas para el asistente de Firebase Studio

## Contexto del Proyecto
Este es un agente de IA construido con **Google ADK (Agent Development Kit)** para analizar
solicitudes de cotización de seguros de flotilla de autos grupales en español.

## Stack Tecnológico
- **Lenguaje**: Python 3.12
- **Framework de agentes**: Google ADK (`google-adk`)
- **Modelo**: Gemini 2.0 Flash / Pro (Vertex AI)
- **Base de datos**: Google Cloud Firestore
- **Almacenamiento**: Google Cloud Storage
- **Procesamiento de docs**: Google Document AI, pdfplumber, pandas, python-docx
- **API**: FastAPI + Uvicorn
- **Gestión de paquetes**: UV (`pyproject.toml`)
- **Infraestructura**: Terraform, Cloud Run, Vertex AI Pipelines
- **CI/CD**: Cloud Build

## Estructura de Archivos Clave
- `app/agent.py` — instanciación del `root_agent` con callbacks
- `app/prompts.py` — instrucciones del sistema en español
- `app/tools.py` — todas las herramientas (PDF, Excel, Word, Gemini, Firestore, GCS)
- `app/config.py` — configuración centralizada con Pydantic Settings
- `app/main.py` — API FastAPI

## Convenciones
- Todo el código y comentarios en **Python 3.12**
- Todas las respuestas al usuario y variables del CSV en **español**
- Usar `structlog` para logging, no `print()`
- Usar `uv run` para ejecutar scripts, no `python` directamente
- Los tools del agente deben tener docstrings detallados en español

## Comandos de Desarrollo Rápido
```bash
uv sync --dev                    # instalar dependencias
adk web app/                     # playground interactivo
uv run pytest -v                 # tests
uv run python eval/eval_runner.py # evaluación del agente
```
