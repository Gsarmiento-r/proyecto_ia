# =============================================================================
# .idx/dev.nix — Firebase Studio workspace configuration for AutoFlota-AI
#
# This file defines the full development environment using Nix.
# Firebase Studio reads this file to provision the workspace automatically.
# Docs: https://firebase.google.com/docs/studio/customize-workspace
# =============================================================================

{ pkgs, ... }: {

  # ── Base channel ────────────────────────────────────────────────────────────
  channel = "stable-24.11";   # Nix packages channel

  # ── System packages ─────────────────────────────────────────────────────────
  packages = [
    # Python runtime
    pkgs.python312
    pkgs.python312Packages.pip

    # UV — fast Python package and venv manager
    pkgs.uv

    # Google Cloud SDK (gcloud, gsutil, bq)
    pkgs.google-cloud-sdk

    # Terraform for infrastructure provisioning
    pkgs.terraform

    # Docker CLI (daemon runs separately in GCP)
    pkgs.docker

    # Git and utilities
    pkgs.git
    pkgs.git-lfs
    pkgs.curl
    pkgs.wget
    pkgs.jq
    pkgs.tree
    pkgs.gh

    # Node.js (for MCP servers and tooling)
    pkgs.nodejs_20
    pkgs.nodePackages.npm

    # Shell helpers
    pkgs.zsh
    pkgs.direnv
  ];

  # ── Environment variables ───────────────────────────────────────────────────
  env = {
    # Google Cloud defaults — override in .env for project-specific values
    GOOGLE_CLOUD_PROJECT    = "autos-ai";
    GOOGLE_CLOUD_LOCATION   = "us-east1";
    VERTEXAI_PROJECT        = "autos-ai";
    VERTEXAI_LOCATION       = "us-east1";

    # Python / UV
    PYTHONUNBUFFERED        = "1";
    PYTHONDONTWRITEBYTECODE = "1";
    UV_LINK_MODE            = "copy";

    # ADK
    ADK_APP_NAME = "autos-ai-agent";

    # Application
    APP_ENV  = "development";
    APP_PORT = "8080";
    LOG_LEVEL = "DEBUG";
  };

  # ── IDE settings ────────────────────────────────────────────────────────────
  idx = {
    # Extensions to install automatically in the workspace
    extensions = [
      "ms-python.python"
      "ms-python.vscode-pylance"
      "ms-python.black-formatter"
      "charliermarsh.ruff"
      "hashicorp.terraform"
      "googlecloudtools.cloudcode"
      "ms-azuretools.vscode-docker"
      "redhat.vscode-yaml"
      "tamasfe.even-better-toml"
      "eamodio.gitlens"
    ];

    # Workspace preview panels
    previews = {
      enable = true;
      previews = {
        # FastAPI server
        api = {
          command   = ["uv" "run" "uvicorn" "app.main:app"
                       "--host" "0.0.0.0" "--port" "8080" "--reload"];
          manager   = "web";
          port      = 8080;
        };

        # ADK Web Playground
        playground = {
          command = ["adk" "web" "app/" "--host" "0.0.0.0" "--port" "8000"];
          manager = "web";
          port    = 8000;
        };
      };
    };

    # Lifecycle hooks
    workspace = {
      # Runs once when the workspace is first created
      onCreate = {
        install-deps = {
          name    = "Instalar dependencias con UV";
          command = ''
            echo "📦 Instalando dependencias del proyecto..."
            uv sync --dev
            echo "✅ Dependencias instaladas"

            echo "📋 Copiando .env.example → .env (si no existe)..."
            [ -f .env ] || cp .env.example .env
            echo "⚠️  Edita .env con tus credenciales de Google Cloud"
          '';
          openFiles = [".env" "app/agent.py" "README.md"];
        };
      };

      # Runs every time the workspace starts
      onStart = {
        check-auth = {
          name    = "Verificar autenticación Google Cloud";
          command = ''
            echo "🔐 Verificando credenciales de Google Cloud..."
            gcloud auth list 2>/dev/null | head -5 || echo "⚠️  Ejecuta: gcloud auth application-default login"
            echo "📁 Proyecto: $(gcloud config get-value project 2>/dev/null || echo 'no configurado')"
          '';
        };
      };
    };
  };
}
